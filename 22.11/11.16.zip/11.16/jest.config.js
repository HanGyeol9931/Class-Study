const config = {
    verbose:true ,
    testMatch : ["<rootDir>/**/*.test.js"]
}

module.exports = config